# Operating Systems Virtual Laboratory
The project aims to create a virtual laboratory for the simulation of some of the concepts and algorithms in operating systems. The project aims in making the understanding of these simulations easier.

## Getting started
The project has the folder named experients where all the experiments reside and index.html file in the root directory. The index.html file is basic structure how the modules of the experiment can be placed to get a webpage for an experiment. The file named canvasandscript.html is the file for simulation.

## Deployment
To run any of the file, the user just needs to download the file and open it in a web browser. Best approach for going about any experiment is start with the introduction. Then we check the theory for understanding the concept, followed by the procedure for understanding how the experiment is to carried out and then going onto the simulation of the experiment. To check out the understanding of the concept quiz can be attended.
